﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int number = int.Parse(Console.ReadLine());
            List<Person> members = new List<Person>();
            for (int i = 1; i <= number; i++)
            {
                var input = Console.ReadLine()
                    .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();
                var name = input[0];
                var age = int.Parse(input[1]);
                Person person = new Person(name, age);
                members.Add(person);
            }
            members
                 .Where(x => x.Age > 30)
                 .OrderBy(x => x.Name)
                 .ToList()
                 .ForEach(x => Console.WriteLine($"{x.Name} - {x.Age}"));
        }
    }
}

