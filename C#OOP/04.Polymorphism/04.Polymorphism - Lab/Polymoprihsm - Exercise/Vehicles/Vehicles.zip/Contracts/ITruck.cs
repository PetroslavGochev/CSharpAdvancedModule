﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles.Contracts
{
    public interface ITruck : IVehicle
    {

    }
}
