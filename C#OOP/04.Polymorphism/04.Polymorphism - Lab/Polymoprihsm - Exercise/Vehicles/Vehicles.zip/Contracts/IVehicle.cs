﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles.Contracts
{
    public interface IVehicle
    {
        public void Driving(double distance);
        public void Refueling(double liters);
    }
}
