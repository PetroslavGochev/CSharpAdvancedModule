﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding.Enumerator
{
    public enum Hero
    {
        Druid,
        Paladin,
        Rogue,
        Warrior,
    }
}
