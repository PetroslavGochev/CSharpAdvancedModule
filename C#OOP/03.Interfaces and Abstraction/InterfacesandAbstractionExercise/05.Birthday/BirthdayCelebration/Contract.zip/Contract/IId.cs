﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BirthdayCelebration.Contract
{
    public interface IId
    {
        public string Id { get; set; }
    }
}
