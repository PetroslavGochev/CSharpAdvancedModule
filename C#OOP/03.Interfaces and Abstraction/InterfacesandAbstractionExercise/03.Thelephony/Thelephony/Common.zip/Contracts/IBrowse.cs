﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Thelephony.Contracts
{
    public interface IBrowse
    {
        public void Browsing(string url);
    }
}
