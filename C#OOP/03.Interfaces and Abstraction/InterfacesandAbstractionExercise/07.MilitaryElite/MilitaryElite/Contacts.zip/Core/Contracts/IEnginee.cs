﻿namespace MilitaryElite.Core.Contracts
{
   public interface IEnginee
    {
        public void Run();
    }
}
