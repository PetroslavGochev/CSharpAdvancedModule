﻿namespace MilitaryElite.Contacts
{
    public interface ISpy : ISoldier
    {
        public int CodeNumber { get; }
    }
}
