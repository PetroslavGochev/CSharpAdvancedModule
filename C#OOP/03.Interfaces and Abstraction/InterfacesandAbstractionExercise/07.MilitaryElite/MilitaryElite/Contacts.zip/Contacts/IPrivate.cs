﻿namespace MilitaryElite.Contacts
{
    public interface IPrivate : ISoldier
    {
        public decimal Salary { get;}
    }
}
