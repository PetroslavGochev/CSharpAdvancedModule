﻿namespace MilitaryElite.Enumerator
{
    public enum State
    {
        inProgress,
        Finished
    }
}
