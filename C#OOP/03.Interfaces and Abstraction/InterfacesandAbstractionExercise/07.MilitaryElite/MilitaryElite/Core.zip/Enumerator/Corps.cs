﻿namespace MilitaryElite.Enumerator
{
    public enum Corps
    {
        Airforces,
        Marines
    }
}
