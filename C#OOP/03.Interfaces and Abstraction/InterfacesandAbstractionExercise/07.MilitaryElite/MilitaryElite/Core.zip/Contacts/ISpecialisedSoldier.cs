﻿using MilitaryElite.Enumerator;

namespace MilitaryElite.Contacts
{
    public interface ISpecialisedSoldier : IPrivate
    {
        public string Corps { get;}
    }
}
