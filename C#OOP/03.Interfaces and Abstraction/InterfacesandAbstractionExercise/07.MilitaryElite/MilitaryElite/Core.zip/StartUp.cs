﻿using MilitaryElite.Core;
using System;

namespace MilitaryElite
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Enginee engine = new Enginee();
            engine.Run();
        }
    }
}
